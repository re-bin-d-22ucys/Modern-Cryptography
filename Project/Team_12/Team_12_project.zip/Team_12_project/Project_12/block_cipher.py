import base64
import os
from flask import Flask, request, render_template

app = Flask(__name__)

def aes_encrypt(plaintext, key, mode):
    key = key.encode('utf-8')
    key = key.ljust(32, b'\0')[:32]
    plaintext = plaintext.encode('utf-8')

    if mode == "ECB":
        encrypted_text = b''
        for i in range(0, len(plaintext), 16):
            block = plaintext[i:i+16]
            encrypted_block = bytes([byte ^ key_byte for byte, key_byte in zip(block, key[i:i+16])])
            encrypted_text += encrypted_block
        return base64.b64encode(encrypted_text).decode('utf-8')

    elif mode == "CBC":
        iv = os.urandom(16)
        encrypted_text = iv
        for i in range(0, len(plaintext), 16):
            block = plaintext[i:i + 16]
            block = bytes([byte ^ iv_byte for byte, iv_byte in zip(block, iv)])
            encrypted_block = bytes([byte ^ key_byte for byte, key_byte in zip(block, key)])
            iv = encrypted_block
            encrypted_text += encrypted_block
        return base64.b64encode(encrypted_text).decode('utf-8')

    elif mode in "CFB":
        iv = os.urandom(16)
        encrypted_text = iv
        for i in range(0, len(plaintext), 16):
            keystream = bytes([byte ^ key_byte for byte, key_byte in zip(iv, key)])
            block = plaintext[i:i + 16]
            encrypted_block = bytes([byte ^ keystream_byte for byte, keystream_byte in zip(block, keystream)])
            iv = encrypted_block
            encrypted_text += encrypted_block
        return base64.b64encode(encrypted_text).decode('utf-8')

    elif mode == "OFB":
        iv = os.urandom(16)
        encrypted_text = iv
        for i in range(0, len(plaintext), 16):
            keystream = bytes([byte ^ key_byte for byte, key_byte in zip(iv, key)])
            block = plaintext[i:i + 16]
            encrypted_block = bytes([byte ^ keystream_byte for byte, keystream_byte in zip(block, keystream)])
            iv = keystream
            encrypted_text += encrypted_block
        return base64.b64encode(encrypted_text).decode('utf-8')

    elif mode == "CTR":
        nonce = os.urandom(8)
        counter = 0
        encrypted_text = nonce
        for i in range(0, len(plaintext), 16):
            counter_block = nonce + counter.to_bytes(8, byteorder='big')
            keystream = bytes([byte ^ key_byte for byte, key_byte in zip(counter_block, key)])
            block = plaintext[i:i + 16]
            encrypted_block = bytes([byte ^ keystream_byte for byte, keystream_byte in zip(block, keystream)])
            counter += 1
            encrypted_text += encrypted_block
        return base64.b64encode(encrypted_text).decode('utf-8')

    else:
        raise ValueError("Invalid mode")

def aes_decrypt(ciphertext_base64, key, mode):
    key = key.encode('utf-8')
    key = key.ljust(32, b'\0')[:32]
    ciphertext = base64.b64decode(ciphertext_base64)

    if mode == "ECB":
        decrypted_text = b''
        for i in range(0, len(ciphertext), 16):
            block = ciphertext[i:i+16]
            decrypted_block = bytes([byte ^ key_byte for byte, key_byte in zip(block, key[i:i+16])])
            decrypted_text += decrypted_block

    elif mode == "CBC":
        iv = ciphertext[:16]  # Extract the IV from the ciphertext
        ciphertext = ciphertext[16:]
        decrypted_text = b''
        for i in range(0, len(ciphertext), 16):
            block = ciphertext[i:i + 16]
            decrypted_block = bytes([byte ^ key_byte for byte, key_byte in zip(block, key)])
            decrypted_block = bytes([byte ^ iv_byte for byte, iv_byte in zip(decrypted_block, iv)])  
            iv = block  # Update IV for the next block
            decrypted_text += decrypted_block

    elif mode == "CFB":
        iv = ciphertext[:16]
        ciphertext = ciphertext[16:]
        decrypted_text = b''
        for i in range(0, len(ciphertext), 16):
            keystream = bytes([byte ^ key_byte for byte, key_byte in zip(iv, key)])
            block = ciphertext[i:i + 16]
            decrypted_block = bytes([byte ^ keystream_byte for byte, keystream_byte in zip(block, keystream)])
            iv = block  # Update IV for the next block
            decrypted_text += decrypted_block

    elif mode == "OFB":
        iv = ciphertext[:16]
        ciphertext = ciphertext[16:]
        decrypted_text = b''
        for i in range(0, len(ciphertext), 16):
            keystream = bytes([byte ^ key_byte for byte, key_byte in zip(iv, key)])
            block = ciphertext[i:i + 16]
            decrypted_block = bytes([byte ^ keystream_byte for byte, keystream_byte in zip(block, keystream)])
            iv = keystream  # Update IV for the next block
            decrypted_text += decrypted_block

    elif mode == "CTR":
        nonce = ciphertext[:8]
        ciphertext = ciphertext[8:]
        decrypted_text = b''
        counter = 0
        for i in range(0, len(ciphertext), 16):
            counter_block = nonce + counter.to_bytes(8, byteorder='big')
            keystream = bytes([byte ^ key_byte for byte, key_byte in zip(counter_block, key)])
            block = ciphertext[i:i + 16]
            decrypted_block = bytes([byte ^ keystream_byte for byte, keystream_byte in zip(block, keystream)])
            counter += 1
            decrypted_text += decrypted_block

    else:
        raise ValueError("Invalid mode")

    return decrypted_text.decode('utf-8')

@app.route('/')
def welcome():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def function():
    var_1 = request.form['var_1']
    var_2 = request.form['var_2']
    mode = request.form['mode']
    operation = request.form['operation']

    if var_1 == '' or var_2 == '':
        entry = "Enter some text in the boxes"
    elif operation == 'Encrypt':
        entry = aes_encrypt(var_1, var_2, mode)
    elif operation == 'Decrypt':
        entry = aes_decrypt(var_1, var_2, mode)
    else:
        entry = "Invalid operation"

    return render_template('index.html', entry=entry)

if __name__ == '__main__':
    app.run(debug=True, port=4849)
